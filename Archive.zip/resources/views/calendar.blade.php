<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title> 
</x-layout>
